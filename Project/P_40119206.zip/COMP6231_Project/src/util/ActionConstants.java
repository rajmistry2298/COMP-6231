package util;

public class ActionConstants {
    
    public static final String CREATE_PLAY = "CREATE PLAYERACCOUNT";
    public static final String PLAY_SIN = "PLAYER SIGNIN";
    public static final String PLAY_SOUT = "PLAYER SINGOUT";
    public static final String TRANSFER_ACCOUNT = "TRANSFER_ACCOUNT";
    public static final String TRANSFERACCOUNT = "TRANSFER ACCOUNT";
    public static final String GET_STATUS = "GET_STATUS";
    public static final String GETSTATUS = "GET STATUS";
    public static final String SUSPEND_PLAY = "SUSPEND PLAYERACCOUNT";

}