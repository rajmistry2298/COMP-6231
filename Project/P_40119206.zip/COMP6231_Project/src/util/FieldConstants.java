package util;

public class FieldConstants {
	public static final String SEPARATOR_PIPE = " ! ";
	public static final String SEPARATOR_COLON = " : ";
	public static final String SEPARATOR_ARROW = " => ";
}
