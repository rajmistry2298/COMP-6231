package util;

public class LocationConstants {

	    public static final String NORTHAMERICA = "NA";
	    public static final String EUROPE = "EU";
	    public static final String ASIA = "AS";
	    public static final String NORTHAMERICA_DESC = "North-America";
	    public static final String EUROPE_DESC = "Europe";
	    public static final String ASIA_DESC = "Asia";
	    public static final String SERVER = "Server";

}
